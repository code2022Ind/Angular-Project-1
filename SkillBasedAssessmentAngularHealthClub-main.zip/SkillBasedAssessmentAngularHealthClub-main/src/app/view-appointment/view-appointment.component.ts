import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-view-appointment',
  templateUrl: './view-appointment.component.html'
})
export class ViewAppointmentComponent implements OnInit {

  constructor() { }

  

  ngOnInit() {
    
  }
  
  getfitness() {
    
  }

  deleteAppointment(){}

  editAppointment(){}
}
