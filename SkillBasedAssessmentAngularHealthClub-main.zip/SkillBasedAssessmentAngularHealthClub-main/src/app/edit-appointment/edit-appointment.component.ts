import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-appointment',
  templateUrl: './edit-appointment.component.html'
})
export class EditAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
